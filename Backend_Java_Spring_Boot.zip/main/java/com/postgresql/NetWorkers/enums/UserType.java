package com.postgresql.NetWorkers.enums;

public enum UserType {
    ADMIN,
    CUSTOMER
}
