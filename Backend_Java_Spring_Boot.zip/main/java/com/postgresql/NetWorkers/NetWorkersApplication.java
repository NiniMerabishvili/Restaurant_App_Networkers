package com.postgresql.NetWorkers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetWorkersApplication {

	public static void main(String[] args) {
		SpringApplication.run(NetWorkersApplication.class, args);
	}

}
