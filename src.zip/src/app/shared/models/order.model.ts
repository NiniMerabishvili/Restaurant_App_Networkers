export interface Order {
    id: string,
    name: string,
    quantity: string
}