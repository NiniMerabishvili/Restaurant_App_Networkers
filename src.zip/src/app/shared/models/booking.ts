export interface Bookings {
    id: string;
    date: Date,
    table_name: string;
}