export interface Tables {
    number: string,
    capacity: string,
    type: Type;
}

export enum Type {
    IDOOR,
    OUTDOOR
}