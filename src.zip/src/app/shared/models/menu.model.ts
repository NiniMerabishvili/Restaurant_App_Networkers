export interface Menu{
        "id":string,
        "type": string,
        "name": string,
        "summary": string,
        "description": string,
        "price": string
}