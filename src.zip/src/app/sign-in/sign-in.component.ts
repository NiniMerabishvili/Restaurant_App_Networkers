import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';
import { RegistrationService } from '../shared/services/registration.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss']
})
export class SignInComponent {
  loginFailed = false;

  form = new FormGroup({
    user: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  });

  constructor(
    private authService: AuthService,
    private registrationService: RegistrationService,
    private router: Router
  ) {}

  onLogin() {
    if (this.form.valid) {
      this.loginFailed = false;

      const enteredUsername = this.form.value.user;
      const enteredPassword = this.form.value.password;

      if (enteredUsername && enteredPassword) {
        this.authService.login(enteredUsername, enteredPassword).subscribe(
          (response) => {
            const userType = response; // assuming the user type is returned from the backend

            if (enteredUsername == 'admin@gmail.com' && enteredPassword == 'admin1') {
              this.router.navigate(['/admin']);
            } else {
              this.router.navigate(['/customer']);
            }
          },
          () => {
            this.loginFailed = true;
          }
        );
      } else {
        this.loginFailed = true;
      }
    }
  }

 

  ngOnInit(): void {}
}
