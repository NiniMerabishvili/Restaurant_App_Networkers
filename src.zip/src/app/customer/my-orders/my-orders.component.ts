import { Component, OnInit } from '@angular/core';
import { Menu } from 'src/app/shared/models/menu.model';
import { MenuService } from 'src/app/shared/services/menu.service';
import { OrderService } from 'src/app/shared/services/order.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Order } from 'src/app/shared/models/order.model';

@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.scss']
})
export class MyOrdersComponent implements OnInit {
  menus: Menu[] = [];
  orders: Order[] = [];
  display: boolean = false;
  displayAddNewItem: boolean = true;
  totalOrderDisplay: boolean = false;

  orderForm = new FormGroup({
    name: new FormControl('', [Validators.required]),
    quantity: new FormControl('', [Validators.required])
  });

  constructor(private menuService: MenuService, private orderService: OrderService) { }

  ngOnInit(): void {
    this.loadMenus();
    this.loadOrders();
  }

  loadMenus() {
    this.menuService.getMenus().subscribe(
      (menus: Menu[]) => {
        this.menus = menus;
      },
      (error) => {
        console.error('Error loading menus', error);
      }
    );
  }

  loadOrders() {
    this.orderService.getOrders().subscribe(o => {
      this.orders = o;
    });
  }

  addOrders() {
    const selectedOrderId: string | null | undefined = this.orderForm.value.name;

    if (selectedOrderId !== null && selectedOrderId !== undefined) {
      const selectedMenu = this.menus.find((menu) => menu.id === selectedOrderId);

      if (selectedMenu) {
        const newOrder: Order = {
          id: '',
          name: `${selectedMenu.name} - ${selectedMenu.price}`,
          quantity: this.orderForm.value.quantity!
        };

        this.orderService.addOrders(newOrder).subscribe(() => {
          this.loadOrders();
          this.calculateTotalPrice();
          this.orderForm.reset(); // Reset the form after adding an order
        });

      } else {
        console.error('Selected menu not found');
      }
    } else {
      console.error('Selected menu ID or quantity is undefined or null');
    }
  }

  confirmOrder() {
    this.displayAddNewItem = false;
    this.totalOrderDisplay = true;
  }

  calculateTotalPrice() {
    const totalPrice = this.orders.reduce((total, order) => {
      const price = parseFloat(order.name.split('-')[1].trim());
      const quantity = parseInt(order.quantity, 10);
      return total + (price * quantity);
    }, 0);

    console.log('Total Price:', totalPrice);
  }

  getTotalPrice(): number {
    return this.orders.reduce((total, order) => {
      const price = parseFloat(order.name.split('-')[1].trim());
      const quantity = parseInt(order.quantity, 10);
      return total + (price * quantity);
    }, 0);
  }

  showDialog() {
    this.display = true;
  }
}
